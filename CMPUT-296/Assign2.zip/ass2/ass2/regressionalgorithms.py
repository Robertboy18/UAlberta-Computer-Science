import numpy as np
import math
import random
import MLCourse.utilities as utils

# -------------
# - Baselines -
# -------------


class Regressor:
    """
    Generic regression interface; returns random regressor
    Random regressor randomly selects w from a Gaussian distribution
    """
    def __init__(self, parameters = {}):
        self.params = parameters
        self.weights = None

    def getparams(self):
        return self.params

    def learn(self, Xtrain, ytrain):
        # Learns using the traindata
        self.weights = np.random.rand(Xtrain.shape[1])

    def predict(self, Xtest):
        # Most regressors return a dot product for the prediction
        ytest = np.dot(Xtest, self.weights)
        return ytest
        
    def get_learned_params(self):
        return {}


class RangePredictor(Regressor):
    """
    Random predictor randomly selects value between max and min in training set.
    """
    def __init__(self, parameters = {}):
        self.params = parameters
        self.min = 0
        self.max = 1

    def learn(self, Xtrain, ytrain):
        # Learns using the traindata
        self.min = np.amin(ytrain)
        self.max = np.amax(ytrain)

    def predict(self, Xtest):
        ytest = np.random.rand(Xtest.shape[0])*(self.max-self.min) + self.min
        return ytest
        
    def get_learned_params(self):
        return {"Min":self.min, "Max": self.max}

class MeanPredictor(Regressor):
    """
    Returns the average target value observed; a reasonable baseline
    """
    def __init__(self, parameters = {}):
        self.params = parameters
        self.mean = None

    def learn(self, Xtrain, ytrain):
        # Learns using the traindata
        self.mean = np.mean(ytrain)

    def predict(self, Xtest):
        return np.ones((Xtest.shape[0],))*self.mean
        
    def get_learned_params(self):
        return {"Mean":self.mean}


# ---------
# - TODO: Question 3-a
# ---------

# Class for a simple stochastic gradient based regression
class SimpleRegression(Regressor):
    
    # Initializes parameters   
    def __init__(self, parameters = {}):
        self.params = utils.update_dictionary_items({'stepsize_b': 0.01, 'epochs': 10}, parameters)        
    # Learns weights for predictions 
    def learn(self, Xtrain, ytrain):        
        numsamples = Xtrain.shape[0]
        numfeatures = Xtrain.shape[1]

        # Initialize variables        
        self.b = np.random.rand(numfeatures)
        # Example of how to access params
        epochs = self.params['epochs']
        
        # Select if adaptive stepsize is needed, if not use a constant one
        # only for 3a
        # for 3d it gets overwritten by nu in the for_loop
        # penalizing the data by reducing stepsize when not using adaptive
        if epochs > 5:
            nu = self.params['stepsize_b']/10
        else:
            nu = self.params['stepsize_b']

        # Shuffle data for every epoch
        # Compute final converged weights to use for the predict(self, Xtest) method
        for __ in range(epochs):
            np.random.shuffle(Xtrain+ytrain)
            for k in range(numsamples):
                nu = 1/(1+abs(np.dot((np.dot(Xtrain[k],self.b) - ytrain[k]),Xtrain[k])))
                self.b = self.b - nu*np.dot((np.dot(Xtrain[k],self.b) - ytrain[k]),Xtrain[k])
                
    # Predicts output values with learned weights
    def predict(self, Xtest):
        ytest = np.dot(Xtest, self.b)
        return ytest
    
    # Returns learned parameters    
    def get_learned_params(self):
        return {"b":self.b}


# ---------
# - TODO: Question 3-c
# ---------

# Class for mini batch gradient based regression
class BatchSimpleRegression(Regressor):

    def __init__(self, parameters = {}):
        self.params = utils.update_dictionary_items({'stepsize_b': 0.01, 'epochs': 10, 'batchsize': 32}, parameters)
        
    def learn(self, Xtrain, ytrain):                        
        numsamples = Xtrain.shape[0]
        numfeatures = Xtrain.shape[1]
        
        # Initialize variables
        self.b = np.random.rand(numfeatures)
        # Example of how to access params
        epochs = self.params['epochs']  
        N_batch = self.params['batchsize']
        
        # Select if adaptive stepsize is needed, if not use a constant one
        if epochs > 5 :
            nu = self.params['stepsize_b']/10
        else:
            nu = self.params['stepsize_b']
        
        # Shuffle data for every epoch  
        # Form minibatches over the shuffled data and use these minibatches to make updates
        # clearly we need 125 epochs but for this assign we are only using 10 so only the 
        # first 320 batches are calculated
        g = 0
        for __ in range(epochs):
            np.random.shuffle(Xtrain+ytrain)
            for j in range(0,numsamples,N_batch):
                for k in range(j,j+N_batch):
                    g += np.dot((np.dot(Xtrain[k],self.b) - ytrain[k]),Xtrain[k])
                    g = g/N_batch
                nu = 1/(1+abs(g))
                self.b = self.b - np.dot(nu,g)
            g = 0
        
        # Compute final converged weights to use for the predict(self, Xtest) method
    
    def predict(self, Xtest):
        ytest = np.dot(Xtest, self.b)
        return ytest
        
    def get_learned_params(self):
        return {"b":self.b}

# ---------
# - TODO: Question 3-f
# ---------

# Class for distribution regression
class DistributionRegression(Regressor):
       
    def __init__(self, parameters = {}):
        self.params = utils.update_dictionary_items({'stepsize_b': 0.0001, 'epochs': 1, 'stepsize_a': 0.0001}, parameters)
        
    def learn(self, Xtrain, ytrain):        
        numsamples = Xtrain.shape[0]
        numfeatures = Xtrain.shape[1]
        
        # Initialize variables
        self.b = np.random.rand(numfeatures)
        self.a = np.random.rand(numfeatures)

        # Example of how to access params
        epochs = self.params['epochs']
        
        # Select if adaptive stepsize is needed, if not use a constant one
        if epochs > 5 :
            nu = self.params['stepsize_b']/10
        else:
            nu = self.params['stepsize_b']
        # Shuffle data for every epoch        
        # Compute final converged weights to use for the predict(self, Xtest) method
        grad_b = 0
        grad_a = 0
        for __ in range(epochs):
            np.random.shuffle(Xtrain+ytrain)
            for j in range(numsamples):
                grad_b = np.dot(-Xtrain[j],ytrain[j]-np.dot(Xtrain[j],self.b))/(np.exp(np.dot(Xtrain[j],self.a)))
                grad_a = 0.5*np.dot(Xtrain[j],1-(pow(ytrain[j]-np.dot(Xtrain[j],self.b),2)))*np.exp(np.dot(-Xtrain[j],self.a))
                nu = 1/(1+pow((pow(grad_b,2) + pow(grad_a,2)),0.5))
                self.b = self.b - np.dot(nu,grad_b)
                self.a = self.a - np.dot(nu,grad_a)
                
    def predict(self, Xtest):
        ytest = np.dot(Xtest, self.b)
        return ytest
                
    def get_learned_params(self):
        return {"b":self.b, "a": self.a}

