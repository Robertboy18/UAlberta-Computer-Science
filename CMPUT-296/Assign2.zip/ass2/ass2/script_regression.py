import csv
import random
import math
import numpy as np
import time 
import regressionalgorithms as algs

import MLCourse.dataloader as dtl
import MLCourse.plotfcns as plotfcns
import matplotlib.pyplot as plt

def l2err(prediction, ytest):
    """ l2 error (i.e., root-mean-squared-error) """
    return np.linalg.norm(np.subtract(prediction, ytest))

def l1err(prediction, ytest):
    """ l1 error """
    return np.linalg.norm(np.subtract(prediction, ytest), ord=1)

def l2err_squared(prediction, ytest):
    """ l2 error squared """
    return np.square(np.linalg.norm(np.subtract(prediction, ytest)))

def geterror(predictions, ytest):
    # Can change this to other error values
    return l2err(predictions, ytest) / np.sqrt(ytest.shape[0])

if __name__ == '__main__':
    start = time.time()
    trainsize = 4000
    testsize = 1000
    numruns = 50
   
    # Numpy random generator seed set to 0 to get the same output everytime we run this script
    np.random.seed(0)

    # Algorithms to run
    regressionalgs = {
        'Random': algs.Regressor,
        'Mean': algs.MeanPredictor,
        'SimpleRegression': algs.SimpleRegression,
        'BatchSimpleRegression': algs.BatchSimpleRegression,
        'DistributionRegression': algs.DistributionRegression
    }
    numalgs = len(regressionalgs)

    # Specify the name of the algorithm and an array of parameter values to try
    # If an algorithm is not included, will run with default parameters
    # This code allows multiple sets of parameters to be tried for each algorithm
    # We leave this generic functionality in the code, but note that for Assignment 2
    # you only need to test one set of parameters for each method
    parameters = {
        'SimpleRegression': [
             { 'stepsize_b': 0.01,
               'epochs': 10,
             },
        ],
        'BatchSimpleRegression': [
             { 'stepsize_b': 0.01,
               'epochs': 10,
               'batchsize': 32,
             },
        ],
        'DistributionRegression': [
            { 'stepsize_b': 0.01, 
             'epochs': 10, 
             'stepsize_a': 0.01
            }
        ]      
    }

    errors = {}
    for learnername in regressionalgs:
        # get the parameters to try for this learner
        # if none specified, then default to an array of 1 parameter setting: None
        params = parameters.get(learnername, [ None ])
        errors[learnername] = np.zeros((len(params), numruns))

    for r in range(numruns):
        trainset, testset = dtl.load_height_weight(trainsize,testsize)
        print(('Running on train={0} and test={1} samples for run {2}').format(trainset[0].shape[0], testset[0].shape[0], r))

        for learnername, Learner in regressionalgs.items():
            params = parameters.get(learnername, [None])
            for p in range(len(params)):
                learner = Learner(params[p])
                print ('Running learner = ' + learnername + ' on parameters ' + str(learner.getparams()))
                
                # Train model
                learner.learn(trainset[0], trainset[1])                
                print("Learned Parameters: ",learner.get_learned_params())
                
                # Make predictions
                trainpredictions = learner.predict(trainset[0])
                testpredictions = learner.predict(testset[0])
                
                # Get prediction error
                trainerror = geterror(trainpredictions, trainset[1])
                testerror = geterror(testpredictions, testset[1])
                
                print ('Training error for ' + learnername + ': ' + str(trainerror))
                print ('Test error for ' + learnername + ': ' + str(testerror))
                errors[learnername][p, r] = testerror
    
    # Extract best parameters
    # For Assignment 2, we are only testing one set of parameters
    # so this loop returns the values for that single set of parameters
    for learnername in regressionalgs:
        params = parameters.get(learnername, [ None ])
        besterror = np.mean(errors[learnername][0, :])
        bestparams = 0
        for p in range(len(params)):
            aveerror = np.mean(errors[learnername][p, :])
            if aveerror < besterror:
                besterror = aveerror
                bestparams = p

        # Report best parameters and error
        best = params[bestparams]
        print ('Best parameters for ' + learnername + ': ' + str(best))
        print ('Average test error for ' + learnername + ': ' + str(besterror) + ' +- ' + str(1.96 * np.std(errors[learnername][bestparams, :]) / math.sqrt(numruns)))
    print ("Time : ",time.time()-start)
    
